<?php

  printf("input number: ");
  fscanf(STDIN,"%d",$d);

    for($b=1;$b<=12;$b++){
    for($a=2;$a<=$d;$a++) {
      printf("%5d",$c=$a*$b);}
  printf("\n");}


  


   

 
  
  